from help import done
import random

class Creature:
    def __init__(self):
        self.order = 0.0

    def turnsPass(self, turns):
        pass

    def getDamage(self, damage):
        pass

    def setOrder(self, newOrder):
        self.order = newOrder

    def getOrder(self):
        return self.order

    def isAlive(self):
        return self.health > 0

    def chanceOfAttack(self):
        return random.randint(1, 6)

    def randomDmgDealt(self):
        return random.randint(2, 9)

    def randomDmgCanceled(self):
        return random.randint(1, 4)

    def attack(self, otherCreature):
        if done(
            self.chanceOfAttack(),
            otherCreature.chanceOfAttack()
        ):
            damage = max(0, self.randomDmgDealt() - self.randomDmgCanceled())
            otherCreature.getDamage(damage)

class Ogr(Creature):
    def __init__(self):
        super().__init__()
        self.health = 20
    def getDamage(self, damage):
        self.health -= damage

class Elf(Creature):
    def __init__(self):
        super().__init__()
        self.health = 10
    def getDamage(self, damage):
        self.health -= damage