import random as R
from creature import Ogr, Elf
from queueOfCreatures import QueueOfCreatures


def oneFight(creature1, creature2):
    def secondCreature(attacker):
        if attacker is creature1:
            return creature2
        return creature1
    qoc = QueueOfCreatures()
    creature1.setOrder(0.0)
    creature2.setOrder(0.0)
    creatures = [creature1 , creature2]
    R.shuffle(creatures)
    qoc.add(creatures[0])
    qoc.add(creatures[1])
    numberOfHits = 0
    while creature1.isAlive() and creature2.isAlive():
        numberOfHits += 1
        attacker = qoc.get()
        attacker.attack(secondCreature(attacker))
        attacker.turnsPass(1)
        qoc.add(attacker)
    if creature1.isAlive():
        return creature1, numberOfHits
    return creature2, numberOfHits

def combatStatistics(class1, class2, numberOfFights):
    numberOfWinsClass1 = 0
    numberOfWinsClass2 = 0
    length = []
    for i in range(numberOfFights):
        whoWins, numberOfHits = oneFight(class1(), class2())
        if isinstance(whoWins, class1):
            numberOfWinsClass1 += 1
        else:
            numberOfWinsClass2 += 1
        length.append(numberOfHits)
    return ("WinsOfClass1:", numberOfWinsClass1, "WinsOfClass2:", numberOfWinsClass2,
            "MinLenOfHits:", min(length), "SumLenOfHits:", sum(length)/numberOfFights,
            "MaxLenOfHits:", max(length))

def main():
    print(combatStatistics(Elf, Ogr, 1000))

if __name__ == '__main__':
    main()