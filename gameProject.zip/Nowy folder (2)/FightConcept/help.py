import random

def done(chance1, chance2):
    return chance1 > chance2
