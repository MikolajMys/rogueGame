class QueueOfCreatures:
    def __init__(self):
        self.queue = []

    def get(self):
        if self.queue:
            return self.queue.pop(0)
        else:
            return None

    def add(self, creature):
        for i in range(len(self.queue)):
            if creature.getOrder() < self.queue[i].getOrder():
                self.queue.insert(i, creature)
                return
        self.queue.append(creature)
