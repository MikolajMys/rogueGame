import random
import curses

class World:
    def __init__(self):
        self.levels = []


class Level:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.fields = [[Field(None, " ", None) for _ in range(width)] for _ in range(height)]
        self.info = ""

    def generate(self):
        for i in range(self.height):
            for j in range(self.width):
                if j == 0 or j == self.width - 1:
                    self.fields[i][j] = Field(None, "║", None)
                    self.fields[i][j].wallPtr = True
                elif i == 0 or i == self.height - 1:
                    self.fields[i][j] = Field(None, "═", None)
                    self.fields[i][j].wallPtr = True
                else:
                    self.fields[i][j] = Field(None, "#", None)
                    self.fields[i][j].wallPtr = True

    # def draw(self):
    #     for row in self.fields:
    #         for field in row:
    #             if field.actorPtr is not None:
    #                 print(field.actorPtr.symbol, end=" ")
    #             elif field.itemPtr is not None:
    #                 print(field.itemPtr.symbol, end=" ")
    #             elif field.creaturePtr is not None:
    #                 print(field.creaturePtr.symbol, end=" ")
    #             else:
    #                 print(field.symbol, end=" ")
    #         print()
    def draw(self, mapWindow, hero):
        mapWindow.clear()

        for row in self.fields:
            for field in row:
                if field.actorPtr is not None and field.actorPtr == hero:
                    mapWindow.addstr(field.actorPtr.symbol)
                    mapWindow.addch(' ')
                elif field.itemPtr is not None:
                    mapWindow.addstr(field.itemPtr.symbol)
                    mapWindow.addch(' ')
                elif field.creaturePtr is not None:
                    mapWindow.addstr(field.creaturePtr.symbol)
                    mapWindow.addch(' ')
                else:
                    mapWindow.addstr(field.symbol)
                    mapWindow.addch(' ')
            mapWindow.addch('\n')
        mapWindow.refresh()

    def draw2(self, mapWindow, hero):
        mapWindow.clear()
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_MAGENTA, curses.COLOR_BLACK)

        # Definiuję rozmiary widocznego obszaru
        view_width = 25  # Szerokość widocznego obszaru
        view_height = 15  # Wysokość widocznego obszaru

        # Obliczam współrzędne lewego górnego rogu widocznego obszaru
        left_top_x = max(hero.x - view_width // 2, 0)
        left_top_y = max(hero.y - view_height // 2, 0)

        # Obliczam współrzędne prawego dolnego rogu widocznego obszaru
        right_bottom_x = min(left_top_x + view_width, self.width)
        right_bottom_y = min(left_top_y + view_height, self.height)

        for j in range(left_top_y, right_bottom_y):
            for i in range(left_top_x, right_bottom_x):
                # Współrzędne na mapie gry
                map_x = i - left_top_x
                map_y = j - left_top_y

                # Współrzędne na ekranie
                screen_x = map_x
                screen_y = map_y

                if self.fields[j][i].actorPtr is not None and self.fields[j][i].actorPtr == hero:
                    mapWindow.addstr(screen_y, screen_x * 2, self.fields[j][i].actorPtr.symbol, curses.color_pair(1))
                    mapWindow.addch(screen_y, screen_x * 2 + 1, ' ')
                elif self.fields[j][i].itemPtr is not None:
                    mapWindow.addstr(screen_y, screen_x * 2, self.fields[j][i].itemPtr.symbol, curses.color_pair(3))
                    mapWindow.addch(screen_y, screen_x * 2 + 1, ' ')
                elif self.fields[j][i].creaturePtr is not None:
                    mapWindow.addstr(screen_y, screen_x * 2, self.fields[j][i].creaturePtr.symbol, curses.color_pair(2))
                    mapWindow.addch(screen_y, screen_x * 2 + 1, ' ')
                else:
                    mapWindow.addstr(screen_y, screen_x * 2, self.fields[j][i].symbol)
                    mapWindow.addch(screen_y, screen_x * 2 + 1, ' ')

        mapWindow.refresh()

    def displayInfo(self, hero, infowindow):
        infowindow.clear()
        heart_count = hero.health // 10
        infowindow.addstr(0, 0, "Health: " + "♥ " * heart_count + " " + str(hero.health*2) + "%")
        infowindow.addstr(1, 0, "Damage: " +  str(hero.damage))
        infowindow.addstr(2, 0, "Defense: " +  str(hero.defense))
        infowindow.addstr(3, 0, "Attack-range: " +  str(hero.range))
        infowindow.addstr(4, 0, "Info:")

        info_lines = self.info.split(", ")
        row = 5
        max_rows = infowindow.getmaxyx()[0] - 1  # Maximum rows in the infowindow


        for i in range(0, len(info_lines), 3):
            info_pair = ", ".join(info_lines[i:i + 3])
            infowindow.addstr(row, 0, info_pair)
            row += 1

            if row >= max_rows:
                # Clear self.info if the displayed lines exceed the maximum rows
                self.info = ""
                break

        infowindow.refresh()

    def displayEquipment(self, hero, equipmetwindow):
        equipmetwindow.clear()

        # max_rows = equipmetwindow.getmaxyx()[0] - 1  # Maximum rows in the equipmetwindow
        equipmetwindow.addstr(0, 0, "Items: " + ", ".join(item.name for item in hero.equipment))

        # if row >= max_rows:
        #     # If the displayed lines exceed the maximum rows, break the loop
        #     break

        equipmetwindow.refresh()

    def hideInfo(self):
        self.previous_info = self.info
        self.info = " INFO-HIDED"

    def isValidLocation(self, x, y):
        return 0 < x < self.width - 1 and 0 < y < self.height - 1

    def isFieldOccupied(self, x, y):
        if self.fields[y][x].actorPtr is not None:
            return False
        elif self.fields[y][x].creaturePtr is not None:
            return False
        elif self.fields[y][x].itemPtr is not None:
            return False
        else:
            return True

    def isWall(self, x, y):
        return self.fields[y][x].wallPtr

    def _saveToFile(self, data):
        with open("report.txt", "a") as file:
            file.write(data + "\n")

    def _removeFromFile(self, target):
        with open("report.txt", "r") as file:
            lines = file.readlines()
        with open("report.txt", "w") as file:
            for line in lines:
                if line.strip() != target:
                    file.write(line)

    def showReport(self):
        try:
            with open("report.txt", "r+") as file:
                content = file.read()
                print("Report content:")
                print(content)
                file.seek(0)
                file.truncate()
        except FileNotFoundError:
            print("File 'report.txt' not found or empty")


class ElementOfGame:
    def __init__(self, name, symbol, description):
        self.name = name
        self.symbol = symbol
        self.description = description


class Field(ElementOfGame):
    def __init__(self, name, symbol, description):
        super().__init__("Field", symbol, "Field on the map")
        self.actorPtr = None
        self.itemPtr = None
        self.creaturePtr = None
        self.wallPtr = False
        self.exitPtr = False
        # poźniej zmien na tablice itemów


class Actor(ElementOfGame):
    def __init__(self, name, symbol, description, x, y):
        super().__init__(name, symbol, description)
        self.x = x
        self.y = y
        self.equipment = []
        # self.behavior = None
