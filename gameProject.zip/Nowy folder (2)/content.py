import curses
import random

class World:
    def __init__(self):
        self.levels = []


class Level:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.fields = [[Field(None, " ", None) for _ in range(width)] for _ in range(height)]
        self.info = " "
        self.previous_info = None

    def generate(self):
        for i in range(self.height):
            for j in range(self.width):
                if j == 0 or j == self.width - 1:
                    self.fields[i][j] = Field(None, "║", None)
                elif i == 0 or i == self.height - 1:
                    self.fields[i][j] = Field(None, "═", None)
                else:
                    self.fields[i][j] = Field(None, ".", None)

    # def draw(self):
    #     for row in self.fields:
    #         for field in row:
    #             if field.actorPtr is not None:
    #                 print(field.actorPtr.symbol, end=" ")
    #             elif field.itemPtr is not None:
    #                 print(field.itemPtr.symbol, end=" ")
    #             elif field.creaturePtr is not None:
    #                 print(field.creaturePtr.symbol, end=" ")
    #             else:
    #                 print(field.symbol, end=" ")
    #         print()
    def draw(self, stdscr, hero):
        stdscr.clear()
        max_width = curses.COLS
        for row in self.fields:
            for field in row:
                if field.actorPtr is not None and field.actorPtr == hero:
                    stdscr.addstr(field.actorPtr.symbol)
                    stdscr.addch(' ')
                elif field.itemPtr is not None:
                    stdscr.addstr(field.itemPtr.symbol)
                    stdscr.addch(' ')
                elif field.creaturePtr is not None:
                    stdscr.addstr(field.creaturePtr.symbol)
                    stdscr.addch(' ')
                else:
                    stdscr.addstr(field.symbol)
                    stdscr.addch(' ')
            stdscr.addch('\n')
        stdscr.addstr(1, 82, "Name: ")
        stdscr.addstr(2, 82, "Health: " + str(hero.health) + "♥")
        stdscr.addstr(3, 82, "Items: " + ", ".join(item.name for item in hero.equipment))
        stdscr.addstr(18, 82, "Info:" + str(self.info))
        stdscr.addstr(19, 82, "=PRESS TAB TO HIDE INFO=")
        if(len(self.info) > max_width-82):
            self.info = " "
        stdscr.refresh()

    def hideInfo(self):
        self.previous_info = self.info
        self.info = " INFO-HIDED"

    def showInfo(self):
        self.info = self.previous_info

    def isValidLocation(self, x, y):
        return 0 < x < self.width - 1 and 0 < y < self.height - 1

    def isOccupiedByCreature(self, x, y):
        if self.fields[y][x].creaturePtr is not None:
            return False
        else:
            return True

    def isOccupiedByItem(self, x, y, Hero):
        if self.fields[y][x].itemPtr is not None:
            item = self.fields[y][x].itemPtr
            Hero.equipment.append(item)
            self.fields[y][x].itemPtr = None

    def spawnHero(self, Hero):
        if self.isValidLocation(Hero.x, Hero.y) and not self.fields[Hero.y][Hero.x].creaturePtr or not self.fields[Hero.y][Hero.x].itemPtr:
            #print("Hero spawned")
            self.info += " " + str(Hero.name) + " spawned,"
            self.fields[Hero.y][Hero.x].actorPtr = Hero
            self._saveToFile(f"Hero spawned at ({Hero.x}, {Hero.y})")
        else:
            self.info = "Invalid location to spawn hero"

    def unlockHeroLocation(self, Hero):
        self.fields[Hero.y][Hero.x].actorPtr = None

    def updateHeroLocation(self, Hero):
        self.fields[Hero.y][Hero.x].actorPtr = Hero

    def useItem(self, item, Hero):
        if item.name == "Mysterious potion":
            Hero.x, Hero.y = random.randint(1, self.width - 2), random.randint(1, self.height - 2)
            self.info += " " + str(Hero.name) + " used " + str(item.name) + ","
            Hero.equipment.remove(item)
        if item.name == "Health potion":
            Hero.health = 50
            self.info += " " + str(Hero.name) + " used " + str(item.name) + ","
            Hero.equipment.remove(item)
        if item.name == "Dagger":
            Hero.health -= 1
            self.info += " " + str(Hero.name) + " used " + str(item.name) + ","
            Hero.equipment.remove(item)

    def spawnItem(self, item, x, y):
        if not self.fields[y][x].actorPtr or not self.fields[y][x].creaturePtr or not isinstance(self.fields[y][x].actorPtr, Hero):
            #print("Item spawned")
            self.info += " " + str(item.name) + " spawned,"
            self.fields[y][x].itemPtr = item
            self._saveToFile(f"Item spawned at ({x}, {y})")
        else:
            self.info = "Can't spawn item, field is occupied by Hero"

    def spawnCreature(self, creature):
        if not self.fields[creature.y][creature.x].actorPtr or not self.fields[creature.y][creature.x].itemPtr or not isinstance(self.fields[creature.y][creature.x].actorPtr, Hero):
            #print("Creature spawned")
            self.info += " " + str(creature.name) + " spawned,"
            self.fields[creature.y][creature.x].creaturePtr = creature
            self._saveToFile(f"Creature spawned at ({creature.x}, {creature.y})")
        else:
            self.info = "Can't spawn creature, field is occupied by Hero"

    def removeHero(self, Hero):
        if isinstance(self.fields[Hero.y][Hero.x].actorPtr, Hero):
            #print("Hero removed")
            self.info += " " + str(Hero.name) + " removed,"
            self.fields[Hero.y][Hero.x].actorPtr = None
            self._removeFromFile(f"Hero spawned at ({Hero.x}, {Hero.y})")
        else:
            self.info = "No Hero found on this field"

    def removeItem(self, item, x, y):
        if self.fields[y][x].itemPtr:
            #print("Item removed")
            self.info += " " + str(item.name) + " removed,"
            self.fields[y][x].itemPtr = None
            self._removeFromFile(f"Item spawned at ({x}, {y})")
        else:
            self.info = "No Item found on this field"

    def removeCreature(self, creature):
        if self.fields[creature.y][creature.x].creaturePtr:
            #print("Creature removed")dd
            self.info += " " + str(creature.name) + " removed,"
            self.fields[creature.y][creature.x].creaturePtr = None
            self._removeFromFile(f"Creature spawned at ({creature.x}, {creature.y})")
        else:
            self.info = "No Creature found on this field"

    def _saveToFile(self, data):
        with open("report.txt", "a") as file:
            file.write(data + "\n")

    def _removeFromFile(self, target):
        with open("report.txt", "r") as file:
            lines = file.readlines()
        with open("report.txt", "w") as file:
            for line in lines:
                if line.strip() != target:
                    file.write(line)

    def showReport(self):
        try:
            with open("report.txt", "r+") as file:
                content = file.read()
                print("Report content:")
                print(content)
                file.seek(0)
                file.truncate()
        except FileNotFoundError:
            print("File 'report.txt' not found or empty")

class ElementOfGame:
    def __init__(self, name, symbol, description):
        self.name = name
        self.symbol = symbol
        self.description = description


class Field(ElementOfGame):
    def __init__(self, name, symbol, description):
        super().__init__("Field", symbol, "Field on the map")
        self.actorPtr = None
        self.itemPtr = None
        self.creaturePtr = None
        # poźniej zmien na tablice itemów


class Actor(ElementOfGame):
    def __init__(self, name, symbol, description, x, y):
        super().__init__(name, symbol, description)
        self.x = x
        self.y = y
        self.equipment = []
        # self.behavior = None


class Prop(ElementOfGame):
    def __init__(self, name, symbol, description):
        super().__init__(name, symbol, description)


class Hero(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 10
        # self.location = location
        # self.equipment = []
        # self.behavior = None


class Creature(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 15
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    #def movement(self):

