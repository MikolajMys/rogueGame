import random

class World:
    def __init__(self):
        self.levels = []


class Level:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.fields = [[Field(None, " ", None) for _ in range(width)] for _ in range(height)]
        self.info = ""
        self.previous_info = None
        self.snake_timer = 0

    def generate(self):
        for i in range(self.height):
            for j in range(self.width):
                if j == 0 or j == self.width - 1:
                    self.fields[i][j] = Field(None, "║", None)
                    self.fields[i][j].wallPtr = True
                elif i == 0 or i == self.height - 1:
                    self.fields[i][j] = Field(None, "═", None)
                    self.fields[i][j].wallPtr = True
                else:
                    self.fields[i][j] = Field(None, "#", None)
                    self.fields[i][j].wallPtr = True

    # def draw(self):
    #     for row in self.fields:
    #         for field in row:
    #             if field.actorPtr is not None:
    #                 print(field.actorPtr.symbol, end=" ")
    #             elif field.itemPtr is not None:
    #                 print(field.itemPtr.symbol, end=" ")
    #             elif field.creaturePtr is not None:
    #                 print(field.creaturePtr.symbol, end=" ")
    #             else:
    #                 print(field.symbol, end=" ")
    #         print()
    def draw(self, mapWindow, hero):
        mapWindow.clear()

        for row in self.fields:
            for field in row:
                if field.actorPtr is not None and field.actorPtr == hero:
                    mapWindow.addstr(field.actorPtr.symbol)
                    mapWindow.addch(' ')
                elif field.itemPtr is not None:
                    mapWindow.addstr(field.itemPtr.symbol)
                    mapWindow.addch(' ')
                elif field.creaturePtr is not None:
                    mapWindow.addstr(field.creaturePtr.symbol)
                    mapWindow.addch(' ')
                else:
                    mapWindow.addstr(field.symbol)
                    mapWindow.addch(' ')
            mapWindow.addch('\n')
        mapWindow.refresh()

    def displayInfo(self, hero, infowindow):
        infowindow.clear()
        heart_count = hero.health // 10
        infowindow.addstr(0, 0, "Health: " + "♥ " * heart_count)
        infowindow.addstr(1, 0, "Info:")

        info_lines = self.info.split(", ")
        row = 2
        max_rows = infowindow.getmaxyx()[0] - 1  # Maximum rows in the infowindow

        for i in range(0, len(info_lines), 3):
            info_pair = ", ".join(info_lines[i:i + 3])
            infowindow.addstr(row, 0, info_pair)
            row += 1

            if row >= max_rows:
                # Clear self.info if the displayed lines exceed the maximum rows
                self.info = ""
                break

        infowindow.refresh()

    def displayEquipment(self, hero, equipmetwindow):
        equipmetwindow.clear()

        # max_rows = equipmetwindow.getmaxyx()[0] - 1  # Maximum rows in the equipmetwindow
        equipmetwindow.addstr(0, 0, "Items: " + ", ".join(item.name for item in hero.equipment))

        # if row >= max_rows:
        #     # If the displayed lines exceed the maximum rows, break the loop
        #     break

        equipmetwindow.refresh()

    def hideInfo(self):
        self.previous_info = self.info
        self.info = " INFO-HIDED"

    def showInfo(self):
        self.info = self.previous_info

    def isValidLocation(self, x, y):
        return 0 < x < self.width - 1 and 0 < y < self.height - 1

    def isOccupiedByCreature(self, x, y):
        if self.fields[y][x].creaturePtr is not None:
            return False
        else:
            return True

    def isOccupiedByItem(self, x, y, Hero):
        if self.fields[y][x].itemPtr is not None:
            item = self.fields[y][x].itemPtr
            Hero.equipment.append(item)
            self.fields[y][x].itemPtr = None

    def spawnHero(self, Hero):
        if self.isValidLocation(Hero.x, Hero.y) and not self.fields[Hero.y][Hero.x].creaturePtr or not \
                self.fields[Hero.y][Hero.x].itemPtr:
            # print("Hero spawned")
            self.info += " " + str(Hero.name) + " spawned,"
            self.fields[Hero.y][Hero.x].actorPtr = Hero
            self._saveToFile(f"{Hero.name} spawned at ({Hero.x}, {Hero.y})")
        else:
            self.info = "Invalid location to spawn hero"

    def unlockHeroLocation(self, Hero):
        self.fields[Hero.y][Hero.x].actorPtr = None

    def updateHeroLocation(self, Hero):
        self.fields[Hero.y][Hero.x].actorPtr = Hero

    def isWall(self, x, y):
        return self.fields[y][x].wallPtr

    def moveHero(self, x, y):
        if 0 < x < self.width - 1 and 0 < y < self.height - 1 and not self.isWall(x, y):
            return True
        else:
            return False

    def relockCreatureLocation(self, Creature):
        oldX, oldY = Creature.x, Creature.y
        self.fields[Creature.y][Creature.x].creaturePtr = None
        Creature.moveCreatureRandomly()
        if Creature.y > 1 and Creature.y < self.height - 2 and Creature.x > 1 and Creature.x < self.width - 2:
            self.fields[Creature.y][Creature.x].creaturePtr = Creature
        else:
            self.fields[oldY][oldX].creaturePtr = Creature

    def useItem(self, item, Hero):
        if item.name == "Mysterious potion":
            Hero.x, Hero.y = random.randint(1, self.width - 2), random.randint(1, self.height - 2)
            self.info += " " + str(Hero.name) + " used " + str(item.name) + ","
            Hero.equipment.remove(item)
        if item.name == "Health potion":
            Hero.health = 50
            self.info += " " + str(Hero.name) + " used " + str(item.name) + ","
            Hero.equipment.remove(item)
        if item.name == "Dagger":
            Hero.health -= 1
            self.info += " " + str(Hero.name) + " used " + str(item.name) + ","
            Hero.equipment.remove(item)

    def spawnItem(self, item, x, y):
        if not self.fields[y][x].actorPtr or not self.fields[y][x].creaturePtr or not isinstance(
                self.fields[y][x].actorPtr, Hero):
            # print("Item spawned")
            self.info += " " + str(item.name) + " spawned,"
            self.fields[y][x].itemPtr = item
            self._saveToFile(f"{item.name} spawned at ({x}, {y})")
        else:
            self.info = "Can't spawn item, field is occupied by Hero"

    def spawnCreature(self, creature):
        if (not self.fields[creature.y][creature.x].actorPtr or not self.fields[creature.y][creature.x].itemPtr
                or not isinstance(self.fields[creature.y][creature.x].actorPtr, Hero)):
            # print("Creature spawned")
            self.info += " " + str(creature.name) + " spawned,"
            self.fields[creature.y][creature.x].creaturePtr = creature
            self._saveToFile(f"{creature.name} spawned at ({creature.x}, {creature.y})")
        else:
            self.info = "Can't spawn creature, field is occupied by Hero"

    def removeHero(self, Hero):
        if isinstance(self.fields[Hero.y][Hero.x].actorPtr, Hero):
            # print("Hero removed")
            self.info += " " + str(Hero.name) + " removed,"
            self.fields[Hero.y][Hero.x].actorPtr = None
            self._removeFromFile(f"Hero spawned at ({Hero.x}, {Hero.y})")
        else:
            self.info = "No Hero found on this field"

    def removeItem(self, item, x, y):
        if self.fields[y][x].itemPtr:
            # print("Item removed")
            self.info += " " + str(item.name) + " removed,"
            self.fields[y][x].itemPtr = None
            self._removeFromFile(f"Item spawned at ({x}, {y})")
        else:
            self.info = "No Item found on this field"

    def removeCreature(self, creature):
        if self.fields[creature.y][creature.x].creaturePtr:
            # print("Creature removed")dd
            self.info += " " + str(creature.name) + " removed,"
            self.fields[creature.y][creature.x].creaturePtr = None
            self._removeFromFile(f"Creature spawned at ({creature.x}, {creature.y})")
        else:
            self.info = "No Creature found on this field"

    def _saveToFile(self, data):
        with open("report.txt", "a") as file:
            file.write(data + "\n")

    def _removeFromFile(self, target):
        with open("report.txt", "r") as file:
            lines = file.readlines()
        with open("report.txt", "w") as file:
            for line in lines:
                if line.strip() != target:
                    file.write(line)

    def showReport(self):
        try:
            with open("report.txt", "r+") as file:
                content = file.read()
                print("Report content:")
                print(content)
                file.seek(0)
                file.truncate()
        except FileNotFoundError:
            print("File 'report.txt' not found or empty")


class ElementOfGame:
    def __init__(self, name, symbol, description):
        self.name = name
        self.symbol = symbol
        self.description = description


class Field(ElementOfGame):
    def __init__(self, name, symbol, description):
        super().__init__("Field", symbol, "Field on the map")
        self.actorPtr = None
        self.itemPtr = None
        self.creaturePtr = None
        self.wallPtr = False
        # poźniej zmien na tablice itemów


class Actor(ElementOfGame):
    def __init__(self, name, symbol, description, x, y):
        super().__init__(name, symbol, description)
        self.x = x
        self.y = y
        self.equipment = []
        # self.behavior = None


class Prop(ElementOfGame):
    def __init__(self, name, symbol, description):
        super().__init__(name, symbol, description)


class Hero(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 10
        # self.location = location
        # self.equipment = []
        # self.behavior = None


class Creature(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 15
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    def moveCreatureRandomly(self):
        # Losowanie liczby od 0 do 6
        random_number = random.randint(0, 6)

        # Sprawdzenie wyniku i zmiana koordynatów kreatury
        if random_number == 0:
            self.x += 1
        elif random_number == 2:
            self.x -= 1
        elif random_number == 4:
            self.y += 1
        elif random_number == 6:
            self.y -= 1
        elif random_number in [1, 3, 5]:
            return
