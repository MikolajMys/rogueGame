import random
from content import Actor

class Creature(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 15
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    def spawnCreature(self, Level, Hero):
        if (not Level.fields[self.y][self.x].actorPtr or not Level.fields[self.y][self.x].itemPtr
                or not isinstance(Level.fields[self.y][self.x].actorPtr, Hero)):
            # print("Creature spawned")
            Level.info += " " + str(self.name) + " spawned,"
            Level.fields[self.y][self.x].creaturePtr = self
            Level._saveToFile(f"{self.name} spawned at ({self.x}, {self.y})")
        else:
            Level.info = "Can't spawn creature, field is occupied by Hero"

    def removeCreature(self, Level):
        if Level.fields[self.y][self.x].creaturePtr:
            # print("Creature removed")dd
            Level.info += " " + str(self.name) + " removed,"
            Level.fields[self.y][self.x].creaturePtr = None
            Level._removeFromFile(f"Creature spawned at ({self.x}, {self.y})")
        else:
            Level.info = "No Creature found on this field"

    def moveCreatureRandomly(self):
        # Losowanie liczby od 0 do 6
        random_number = random.randint(0, 6)

        # Sprawdzenie wyniku i zmiana koordynatów kreatury
        if random_number == 0:
            self.x += 1
        elif random_number == 2:
            self.x -= 1
        elif random_number == 4:
            self.y += 1
        elif random_number == 6:
            self.y -= 1
        elif random_number in [1, 3, 5]:
            return

    def relockCreatureLocation(self, Level):
        oldX, oldY = self.x, self.y
        Level.fields[self.y][self.x].creaturePtr = None
        self.moveCreatureRandomly()
        if self.y > 1 and self.y < Level.height - 2 and self.x > 1 and self.x < Level.width - 2 and not Level.isWall(self.x, self.y):
            Level.fields[self.y][self.x].creaturePtr = self
        else:
            Level.fields[oldY][oldX].creaturePtr = self