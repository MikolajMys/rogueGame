import random
from content import Actor

class Creature(Actor):
    def __init__(self, name, symbol, description, x, y, health, damage, defense, range):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = damage
        self.defense = defense
        self.range = range
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    def spawnCreature(self, Level, Hero):
        if (not Level.fields[self.y][self.x].actorPtr or not Level.fields[self.y][self.x].itemPtr
                or not isinstance(Level.fields[self.y][self.x].actorPtr, Hero)):
            # print("Creature spawned")
            Level.info += " " + str(self.name) + " spawned,"
            Level.fields[self.y][self.x].creaturePtr = self
            Level._saveToFile(f"{self.name} spawned at ({self.x}, {self.y})")
        else:
            Level.info = "Can't spawn creature, field is occupied by Hero"

    def removeCreature(self, Level):
        if Level.fields[self.y][self.x].creaturePtr:
            Level.info += " " + str(self.name) + " slayed,"
            Level.fields[self.y][self.x].creaturePtr = None
            Level._removeFromFile(f"Creature spawned at ({self.x}, {self.y})")

            # Dodatkowy krok: Zaktualizuj współrzędne stworzenia na poza mapą
            self.x = -1
            self.y = -1
        else:
            Level.info = "No Creature found on this field"

    def moveCreature(self, Level, x, y):
        if (0 < x < Level.width - 1 and 0 < y < Level.height - 1 and not Level.isWall(x, y) and
                Level.fields[y][x].itemPtr is None and Level.fields[y][x].actorPtr is None):
            return True
        else:
            return False

    def moveCreatureRandomly(self, Level):
        # Losowanie liczby od 0 do 6
        random_number = random.randint(0, 6)

        # Sprawdzenie wyniku i zmiana koordynatów kreatury
        if random_number == 0 and self.moveCreature(Level, self.x + 1, self.y):
            self.x += 1
        elif random_number == 2 and self.moveCreature(Level, self.x - 1, self.y):
            self.x -= 1
        elif random_number == 4 and self.moveCreature(Level, self.x, self.y + 1):
            self.y += 1
        elif random_number == 6 and self.moveCreature(Level, self.x, self.y -1):
            self.y -= 1
        elif random_number in [1, 3, 5]:
            return

    def relocateCreatureLocation(self, Level):
        if Level.fields[self.y][self.x].creaturePtr == self and self.x != -1 and self.y != -1:
            oldX, oldY = self.x, self.y
            Level.fields[self.y][self.x].creaturePtr = None
            self.moveCreatureRandomly(Level)
            Level.fields[self.y][self.x].creaturePtr = self
            # self.fight(Level)

    def inRange(self, Level, Direction):
        if Level.fields[self.y+self.range][self.x].actorPtr is not None and Direction == 2:
            return True
        elif Level.fields[self.y][self.x+self.range].actorPtr is not None and Direction == 4:
            return True
        elif Level.fields[self.y-self.range][self.x].actorPtr is not None and Direction == 1:
            return True
        elif Level.fields[self.y][self.x-self.range].actorPtr is not None and Direction == 3:
            return True
        else:
            return False

    def dealDamage(self, hero):
        hero.health -= self.damage

    def fight(self, Level):
        if Level.fields[self.y][self.x].creaturePtr == self and self.x != -1 and self.y != -1:
            if self.inRange(Level, 1):
                creature_on_field = Level.fields[self.y - self.range][self.x].actorPtr
                if creature_on_field:
                    Level.info += f" {self.name} hit you, "
                    self.dealDamage(creature_on_field)
            if self.inRange(Level, 2):
                creature_on_field = Level.fields[self.y + self.range][self.x].actorPtr
                if creature_on_field:
                    Level.info += f" {self.name} hit you, "
                    self.dealDamage(creature_on_field)
            elif self.inRange(Level, 3):
                creature_on_field = Level.fields[self.y][self.x - self.range].actorPtr
                if creature_on_field:
                    Level.info += f" {self.name} hit you, "
                    self.dealDamage(creature_on_field)
            elif self.inRange(Level, 4):
                creature_on_field = Level.fields[self.y][self.x + self.range].actorPtr
                if creature_on_field:
                    Level.info += f" {self.name} hit you, "
                    self.dealDamage(creature_on_field)
