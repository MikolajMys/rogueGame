import random
from content import Actor

class Creature(Actor):
    def __init__(self, name, symbol, description, x, y, health, damage, defense, range):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = damage
        self.defense = defense
        self.range = range
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    def spawnCreature(self, Level, Hero):
        if (not Level.fields[self.y][self.x].actorPtr or not Level.fields[self.y][self.x].itemPtr
                or not isinstance(Level.fields[self.y][self.x].actorPtr, Hero)):
            # print("Creature spawned")
            Level.info += " " + str(self.name) + " spawned,"
            Level.fields[self.y][self.x].creaturePtr = self
            Level._saveToFile(f"{self.name} spawned at ({self.x}, {self.y})")
        else:
            Level.info = "Can't spawn creature, field is occupied by Hero"

    def removeCreature(self, Level):
        if Level.fields[self.y][self.x].creaturePtr:
            # print("Creature removed")dd
            Level.info += " " + str(self.name) + " removed,"
            Level.fields[self.y][self.x].creaturePtr = None
            Level._removeFromFile(f"Creature spawned at ({self.x}, {self.y})")
        else:
            Level.info = "No Creature found on this field"

    def moveCreature(self, Level, x, y):
        if (0 < x < Level.width - 1 and 0 < y < Level.height - 1 and not Level.isWall(x, y) and
                Level.fields[y][x].itemPtr is None and Level.fields[y][x].actorPtr is None):
            return True
        else:
            return False

    def moveCreatureRandomly(self, Level):
        # Losowanie liczby od 0 do 6
        random_number = random.randint(0, 6)

        # Sprawdzenie wyniku i zmiana koordynatów kreatury
        if random_number == 0 and self.moveCreature(Level, self.x + 1, self.y):
            self.x += 1
        elif random_number == 2 and self.moveCreature(Level, self.x - 1, self.y):
            self.x -= 1
        elif random_number == 4 and self.moveCreature(Level, self.x, self.y + 1):
            self.y += 1
        elif random_number == 6 and self.moveCreature(Level, self.x, self.y -1):
            self.y -= 1
        elif random_number in [1, 3, 5]:
            return

    def relocateCreatureLocation(self, Level):
        oldX, oldY = self.x, self.y
        Level.fields[self.y][self.x].creaturePtr = None
        self.moveCreatureRandomly(Level)
        Level.fields[self.y][self.x].creaturePtr = self
