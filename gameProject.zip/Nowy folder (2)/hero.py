from content import Actor, Level


class Hero(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 10
        self.defense = 0
        self.range = 1
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    def spawnHero(self, Level):
        if Level.isValidLocation(self.x, self.y) and Level.isFieldOccupied(self.x, self.y):
            # print("Hero spawned")
            Level.info += " " + str(self.name) + " spawned,"
            Level.fields[self.y][self.x].actorPtr = self
            Level._saveToFile(f"{self.name} spawned at ({self.x}, {self.y})")
        else:
            Level.info = "Invalid location to spawn hero"

    def removeHero(self, Level):
        if isinstance(Level.fields[self.y][self.x].actorPtr, self):
            Level.info += " " + str(self.name) + " removed,"
            Level.fields[self.y][self.x].actorPtr = None
            Level._removeFromFile(f"Hero spawned at ({self.x}, {self.y})")
        else:
            Level.info = "No Hero found on this field"

    def unlockHeroLocation(self, Level):
        Level.fields[self.y][self.x].actorPtr = None

    def updateHeroLocation(self, Level):
        Level.fields[self.y][self.x].actorPtr = self

    def moveHero(self, Level, x, y):
        if 0 < x < Level.width - 1 and 0 < y < Level.height - 1 and not Level.isWall(x, y):
            return True
        else:
            return False

    def inRange(self, Level, Direction):
        if Level.fields[self.y+self.range][self.x].creaturePtr is not None and Direction == 2:
            return True
        elif Level.fields[self.y][self.x+self.range].creaturePtr is not None and Direction == 4:
            return True
        elif Level.fields[self.y-self.range][self.x].creaturePtr is not None and Direction == 1:
            return True
        elif Level.fields[self.y][self.x-self.range].creaturePtr is not None and Direction == 3:
            return True
        else:
            return False

    def fight(self, Level, Direction):
        if self.isOccupiedByCreature(Level, self.x, self.y+self.range) and Direction == 1:
            Level.info += "you hit up"
        if self.isOccupiedByCreature(Level, self.x, self.y-self.range) and Direction == 2:
            Level.info += "you hit down"
        elif self.isOccupiedByCreature(Level, self.x+self.range, self.y) and Direction == 3:
            Level.info += "you hit left"
        elif self.isOccupiedByCreature(Level, self.x-self.range, self.y) and Direction == 4:
            Level.info += "you hit right"

    def isOccupiedByItem(self, Level, x, y):
        if Level.fields[y][x].itemPtr is not None:
            item = Level.fields[y][x].itemPtr
            self.equipment.append(item)
            Level.fields[y][x].itemPtr = None

    def isOccupiedByCreature(self, Level, x, y):
        if Level.fields[y][x].creaturePtr is not None:
            return False
        else:
            return True
