from content import Actor, Level


class Hero(Actor):
    def __init__(self, name, symbol, description, x, y, health):
        super().__init__(name, symbol, description, x, y)
        self.health = health
        self.damage = 10
        self.defense = 0
        self.range = 1
        # self.location = location
        # self.equipment = []
        # self.behavior = None

    def resetStats(self):
        self.health = 100
        self.damage = 10
        self.defense = 0
        self.range = 1
        self.equipment = []

    def spawnHero(self, Level):
        if Level.isValidLocation(self.x, self.y) and Level.isFieldOccupied(self.x, self.y):
            # print("Hero spawned")
            Level.info += " " + str(self.name) + " spawned,"
            Level.fields[self.y][self.x].actorPtr = self
            Level._saveToFile(f"{self.name} spawned at ({self.x}, {self.y})")
        else:
            Level.info = "Invalid location to spawn hero"

    def removeHero(self, Level):
        if isinstance(Level.fields[self.y][self.x].actorPtr, self):
            Level.info += " " + str(self.name) + " removed,"
            Level.fields[self.y][self.x].actorPtr = None
            Level._removeFromFile(f"Hero spawned at ({self.x}, {self.y})")
        else:
            Level.info = "No Hero found on this field"

    def unlockHeroLocation(self, Level):
        Level.fields[self.y][self.x].actorPtr = None

    def updateHeroLocation(self, Level):
        Level.fields[self.y][self.x].actorPtr = self

    def moveHero(self, Level, x, y):
        if 0 < x < Level.width - 1 and 0 < y < Level.height - 1 and not Level.isWall(x, y):
            return True
        else:
            return False

    def inRange(self, Level, Direction):
        if Level.fields[self.y+self.range][self.x].creaturePtr is not None and Direction == 2:
            return True
        elif Level.fields[self.y][self.x+self.range].creaturePtr is not None and Direction == 4:
            return True
        elif Level.fields[self.y-self.range][self.x].creaturePtr is not None and Direction == 1:
            return True
        elif Level.fields[self.y][self.x-self.range].creaturePtr is not None and Direction == 3:
            return True
        else:
            return False

    def dealDamage(self, creature, Level):
        if creature.health > 0:
            creature.health -= self.damage
        else:
            creature.removeCreature(Level)


    def fight(self, Level, Direction):
        if Direction == 1 and self.inRange(Level, Direction):
            creature_on_field = Level.fields[self.y - self.range][self.x].creaturePtr
            if creature_on_field:
                Level.info += f" you hit {creature_on_field.name},"
                self.dealDamage(creature_on_field, Level)
        if Direction == 2 and self.inRange(Level, Direction):
            creature_on_field = Level.fields[self.y + self.range][self.x].creaturePtr
            if creature_on_field:
                Level.info += f" you hit {creature_on_field.name},"
                self.dealDamage(creature_on_field, Level)
        elif Direction == 3 and self.inRange(Level, Direction):
            creature_on_field = Level.fields[self.y][self.x - self.range].creaturePtr
            if creature_on_field:
                Level.info += f" you hit {creature_on_field.name},"
                self.dealDamage(creature_on_field, Level)
        elif Direction == 4 and self.inRange(Level, Direction):
            creature_on_field = Level.fields[self.y][self.x + self.range].creaturePtr
            if creature_on_field:
                Level.info += f" you hit {creature_on_field.name},"
                self.dealDamage(creature_on_field, Level)

    def isOccupiedByItem(self, Level, x, y):
        if Level.fields[y][x].itemPtr is not None:
            item = Level.fields[y][x].itemPtr
            self.equipment.append(item)
            Level.fields[y][x].itemPtr = None

    def isOccupiedByCreature(self, Level, x, y):
        if Level.fields[y][x].creaturePtr is not None:
            return False
        else:
            return True
