
class equipment:
    def __init__(self, info):
        self.info = info
