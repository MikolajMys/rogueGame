import curses
from content import Level, Hero, Prop, Creature

def main(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(1)
    stdscr.clear()

    width = 40
    height = 20

    level = Level(width, height)
    level.generate()

    hero = Hero("Player", "@", "Main character", width // 2, height // 2, 50)
    # sword = Prop("Sword", "!", "Melee weapon")
    # rat = Creature("Rat", "S", "First enemy", 3)
    # goblin = Creature("Player", "G", "Small enemy", 10)
    # skeleton = Creature("Skeleton", "I", "Medium enemy", 15)
    # zombie =  Creature("Zombie", "Z", "Hard medium enemy", 20)
    # ogr = Creature("Ogr", "X", "Big enemy", 30)
    #level.spawnHero(hero)
    # level.spawnCreature(rat, 2 , 15)
    # level.spawnCreature(goblin, 15, 2)
    # level.spawnCreature(skeleton, 30, 10)
    # level.spawnCreature(zombie, 20, 5)
    # level.spawnCreature(ogr, 25, 12)
    # level.spawnItem(sword, 10, 10)

    #level.showReport()
    #level.removeHero(20, 10)
    #level.removeItem(10, 10)
    #level.draw()
    #level.showReport()
    while True:
        level.draw(stdscr, hero)
        key = stdscr.getch()
        #draw_map(stdscr, player_x, player_y, items)
        level.unlockHeroLocation(hero)
        if key == ord('q'):
            break
        elif key == ord('w') and hero.y > 1:
            hero.y -= 1
        elif key == ord('s') and hero.y < height - 2:
            hero.y += 1
        elif key == ord('a') and hero.x > 1:
            hero.x -= 1
        elif key == ord('d') and hero.x < width - 2:
            hero.x += 1


        level.updateHeroLocation(hero)

if __name__ == "__main__":
    curses.wrapper(main)
