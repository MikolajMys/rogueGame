import curses
import random
from content import Level, Field
from hero import Hero
from prop import Prop
from creature import Creature
from mapGenerator import create_rooms, connect_rooms, fill, carve_map, Room, create_test_rooms
from startWindow import start_screen, end_screen


def main(stdscr):
    curses.curs_set(1)
    stdscr.nodelay(1)
    stdscr.clear()
    clicked = True

    width = 40
    height = 20

    level = Level(width, height)
    level.generate()

    num_rooms = 6
    min_room_size = 3
    max_room_size = 6
    rooms = create_rooms(level, num_rooms, min_room_size, max_room_size)
    # rooms = create_test_rooms(level)
    size = len(rooms)

    # Łączenie pokojów korytarzami
    connect_rooms(level, rooms)

    startX, startY = rooms[0].get_center()
    exitX, exitY = rooms[1].get_center()
    level.fields[exitY][exitX].symbol = "█"
    level.fields[exitY][exitX].exitPtr = True
    start2X, start2Y = rooms[random.randint(2, size - 1)].get_center()
    start3X, start3Y = rooms[random.randint(2, size - 1)].get_random_corner()
    start4X, start4Y = rooms[random.randint(3, size - 1)].get_random_corner()
    start5X, start5Y = rooms[random.randint(2, size - 1)].get_random_corner()
    hero = Hero("Player", "θ", "Main character", startX, startY, 50)
    dagger = Prop("Dagger", "†", "Melee weapon", 3,0)
    sword = Prop("Sword", "!", "Heavy melee weapon", 6, 1)
    healthPotion = Prop("Health potion", "ȣ", "Magical relic", 0, 0)
    mysteriousPotion = Prop("Mysterious potion", "ꝿ", "Magical relic", 0, 0)
    snake = Creature("Snake", "ʆ", "First enemy", start2X, start2Y, 3, 2, 0, 1)
    goblin = Creature("Goblin", "ʛ", "Small enemy", random.randint(1, width - 2), random.randint(1, height - 2), 10, 5,
                      2, 1)
    skeleton = Creature("Skeleton", "ꭅ", "Medium enemy", random.randint(1, width - 2), random.randint(1, height - 2),
                        15, 4, 1, 1)
    zombie = Creature("Zombie", "Ѫ", "Hard medium enemy", random.randint(1, width - 2), random.randint(1, height - 2),
                      20, 6, 2, 1)
    ogr = Creature("Ogr", "ʘ", "Big enemy", -1, -1, 30, 10, 6, 2)
    # ʘ ʛ ѫ Ѫ ῐ ⱺ ꭅ Ѧ Ѡ д ¤ ☺ ꝉ † Ȣ ȣ θ Ω Θ Ϙ Ϫ Ϯ ϴ Д Ѳ Ө ֍ ۩ ᴪ ψ Ψ Ω ! ═ ║
    hero.spawnHero(level)
    snake.spawnCreature(level, hero)
    # level.spawnCreature(goblin)
    # level.spawnCreature(skeleton)
    # level.spawnCreature(zombie)
    # level.spawnCreature(ogr)
    dagger.spawnItem(level, start3X, start3Y)
    # level.spawnItem(sword, random.randint(1, width - 2), random.randint(1, height - 2))
    healthPotion.spawnItem(level, start4X, start4Y)
    mysteriousPotion.spawnItem(level, start5X, start5Y)

    mapWindow = curses.newwin(21 - 2, 85 - 4, 2, 4)
    infoWindow = curses.newwin(20, 80, 0, 85)
    equipmentWindow = curses.newwin(10, 100, 21, 0)

    # level.showReport()
    # level.removeHero(20, 10)
    # level.removeItem(10, 10)
    # level.draw()
    # level.showReport()
    while hero.health > 0:
        level.draw2(mapWindow, hero)
        level.displayInfo(hero, infoWindow)
        level.displayEquipment(hero, equipmentWindow)
        snake.relocateCreatureLocation(level)
        snake.fight(level)
        ogr.relocateCreatureLocation(level)
        ogr.fight(level)

        key = mapWindow.getkey()
        # draw_map(stdscr, player_x, player_y, items)
        hero.unlockHeroLocation(level)

        if key == 'q':
            level.showReport()
            break
        # elif key == ord('\t'):
        #     if clicked == True:
        #         level.hideInfo()
        #         clicked = Falsed
        #     elif clicked == False:
        #         level.showInfo()
        #         clicked = True
        # show info
        elif key == 'i' and hero.inRange(level, 1):
            hero.fight(level, 1)
        elif key == 'k' and hero.inRange(level, 2):
            hero.fight(level, 2)
        elif key == 'j' and hero.inRange(level, 3):
            hero.fight(level, 3)
        elif key == 'l' and hero.inRange(level, 4):
            hero.fight(level, 4)
        elif key == 'c':
            hero.health -= 10
        elif key == 'r':
            snake.removeCreature(level)
        elif (key == 'w' and hero.moveHero(level, hero.x, hero.y - 1) and
              hero.isOccupiedByCreature(level, hero.x, hero.y - 1)):
            hero.y -= 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif (key == 's' and hero.moveHero(level, hero.x, hero.y + 1) and
              hero.isOccupiedByCreature(level, hero.x, hero.y + 1)):
            hero.y += 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif (key == 'a' and hero.moveHero(level, hero.x - 1, hero.y) and
              hero.isOccupiedByCreature(level, hero.x - 1, hero.y)):
            hero.x -= 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif (key == 'd' and hero.moveHero(level, hero.x + 1, hero.y) and
              hero.isOccupiedByCreature(level, hero.x + 1, hero.y)):
            hero.x += 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif key == '1':
            if len(hero.equipment) > 0:
                hero.equipment[0].useItem(hero, level, rooms)
        elif key == '2':
            if len(hero.equipment) > 1:
                hero.equipment[1].useItem(hero, level, rooms)
        elif key == '3':
            if len(hero.equipment) > 2:
                hero.equipment[2].useItem(hero, level, rooms)
        elif key == '4':
            if len(hero.equipment) > 3:
                hero.equipment[3].useItem(hero, level, rooms)
        elif key == 'e' and level.fields[hero.y][hero.x].exitPtr:
            snake.removeCreature(level)
            level.fields[hero.y][hero.x].exitPtr = False
            level = Level(width, height)
            level.generate()
            rooms = carve_map(level)
            size = len(rooms)
            connect_rooms(level, rooms)
            startX, startY = rooms[0].get_center()
            start2X, start2Y = rooms[random.randint(1, size - 1)].get_center()
            start3X, start3Y = rooms[random.randint(1, size - 1)].get_random_corner()
            ogr.x = start2X
            ogr.y = start2Y
            hero.x, hero.y = startX, startY
            hero.spawnHero(level)
            ogr.spawnCreature(level, hero)
            sword.spawnItem(level, start3X, start3Y)
            # ogr.relocateCreatureLocation(level)
            # ogr.fight(level)
            # level.fields[hero.y][hero.x].exitPtr = False  # Usuń drzwi z obecnego poziomu
            # fill(level)
            # curses.wrapper(main)  # Uruchom main ponownie
            # break

        hero.updateHeroLocation(level)
        mapWindow.refresh()


if __name__ == "__main__":
    curses.wrapper(start_screen)
    curses.wrapper(main)
    curses.wrapper(end_screen)