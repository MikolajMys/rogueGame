import curses
import random
import time
from content import Level
from hero import Hero
from prop import Prop
from creature import Creature
from mapGenerator import create_rooms, connect_rooms, Room


def main(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(1)
    stdscr.clear()
    clicked = True

    width = 40
    height = 20

    level = Level(width, height)
    level.generate()

    num_rooms = 6
    min_room_size = 3
    max_room_size = 6
    rooms = create_rooms(level, num_rooms, min_room_size, max_room_size)

    # Łączenie pokojów korytarzami
    connect_rooms(level, rooms)
    startX, startY = rooms[0].get_center()
    start2X, start2Y = rooms[random.randint(1, 6)].get_center()
    hero = Hero("Player", "θ", "Main character", startX, startY, 50)
    dagger = Prop("Dagger", "†", "Melee weapon")
    sword = Prop("Sword", "!", "Heavy melee weapon")
    healthPotion = Prop("Health potion", "ȣ", "Magical relic")
    mysteriousPotion = Prop("Mysterious potion", "ꝿ", "Magical relic")
    snake = Creature("Snake", "ʆ", "First enemy", start2X, start2Y, 3)
    goblin = Creature("Goblin", "ʛ", "Small enemy", random.randint(1, width - 2), random.randint(1, height - 2), 10)
    skeleton = Creature("Skeleton", "ꭅ", "Medium enemy", random.randint(1, width - 2), random.randint(1, height - 2),
                        15)
    zombie = Creature("Zombie", "Ѫ", "Hard medium enemy", random.randint(1, width - 2), random.randint(1, height - 2),
                      20)
    ogr = Creature("Ogr", "ʘ", "Big enemy", random.randint(1, width - 2), random.randint(1, height - 2), 30)
    # ʘ ʛ ѫ Ѫ ῐ ⱺ ꭅ Ѧ Ѡ д ¤ ☺ ꝉ † Ȣ ȣ θ Ω Θ Ϙ Ϫ Ϯ ϴ Д Ѳ Ө ֍ ۩ ᴪ ψ Ψ Ω ! ═ ║
    hero.spawnHero(level)
    snake.spawnCreature(level, hero)
    # level.spawnCreature(goblin)
    # level.spawnCreature(skeleton)
    # level.spawnCreature(zombie)
    # level.spawnCreature(ogr)
    # level.spawnItem(dagger, random.randint(1, width - 2), random.randint(1, height - 2))
    # level.spawnItem(sword, random.randint(1, width - 2), random.randint(1, height - 2))
    # level.spawnItem(healthPotion, random.randint(1, width - 2), random.randint(1, height - 2))
    # mysteriousPotion.spawnItem(level, startX, startY)

    mapWindow = curses.newwin(21, 85, 0, 0)
    infoWindow = curses.newwin(20, 80, 0, 85)
    equipmentWindow = curses.newwin(10, 100, 22, 0)

    # level.showReport()
    # level.removeHero(20, 10)
    # level.removeItem(10, 10)
    # level.draw()
    # level.showReport()
    while True:
        level.draw(mapWindow, hero)
        level.displayInfo(hero, infoWindow)
        level.displayEquipment(hero, equipmentWindow)
        # level.relockCreatureLocation(snake)

        key = mapWindow.getch()
        # draw_map(stdscr, player_x, player_y, items)
        hero.unlockHeroLocation(level)

        if key == ord('q'):
            level.showReport()
            break
        # elif key == ord('\t'):
        #     if clicked == True:
        #         level.hideInfo()
        #         clicked = False
        #     elif clicked == False:
        #         level.showInfo()
        #         clicked = True
        # show info
        elif key == ord('c'):
            snake.spawnCreature(level, hero)
        elif key == ord('r'):
            snake.removeCreature(level)
        elif key == ord('w') and hero.moveHero(level, hero.x, hero.y - 1) and hero.isOccupiedByCreature(level, hero.x,
                                                                                                        hero.y - 1):
            hero.y -= 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif key == ord('s') and hero.moveHero(level, hero.x, hero.y + 1) and hero.isOccupiedByCreature(level, hero.x,
                                                                                                        hero.y + 1):
            hero.y += 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif key == ord('a') and hero.moveHero(level, hero.x - 1, hero.y) and hero.isOccupiedByCreature(level,
                                                                                                        hero.x - 1,
                                                                                                        hero.y):
            hero.x -= 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif key == ord('d') and hero.moveHero(level, hero.x + 1, hero.y) and hero.isOccupiedByCreature(level,
                                                                                                        hero.x + 1,
                                                                                                        hero.y):
            hero.x += 1
            hero.isOccupiedByItem(level, hero.x, hero.y)
        elif key == ord('1'):
            if len(hero.equipment) > 0:
                hero.equipment[0].useItem(hero, level)
        elif key == ord('2'):
            if len(hero.equipment) > 1:
                hero.equipment[1].useItem(hero, level)
        elif key == ord('3'):
            if len(hero.equipment) > 2:
                hero.equipment[2].useItem(hero, level)
        elif key == ord('4'):
            if len(hero.equipment) > 3:
                hero.equipment[3].useItem(hero, level)

        hero.updateHeroLocation(level)

        mapWindow.refresh()


if __name__ == "__main__":
    curses.wrapper(main)
