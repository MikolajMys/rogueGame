import random
from content import Level


class Room:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def intersects(self, Level, new_room):
        return (0 < new_room.x < Level.width - 1 and 0 < new_room.y < Level.height - 1
                and not Level.isWall(new_room.x - 1, new_room.y - 1) and not Level.isWall(new_room.height + 1,
                                                                                          new_room.width + 1))

    def get_center(self):
        center_x = self.x + self.width // 2
        center_y = self.y + self.height // 2
        return center_x, center_y


def create_rooms(Level, num_rooms, min_size, max_size):
    rooms = []

    for _ in range(num_rooms):
        room_width = random.randint(min_size, max_size)
        room_height = random.randint(min_size, max_size)

        x = random.randint(1, Level.width - room_width - 1)
        y = random.randint(1, Level.height - room_height - 1)

        new_room = Room(x, y, room_width, room_height)

        if not any(room.intersects(Level, new_room) for room in rooms):
            rooms.append(new_room)
            for i in range(new_room.y, new_room.y + new_room.height):
                for j in range(new_room.x, new_room.x + new_room.width):
                    Level.fields[i][j].symbol = "."
                    Level.fields[i][j].wallPtr = False

    return rooms


def connect_rooms(Level, rooms):
    for i in range(len(rooms) - 1):
        start_x = rooms[i].x + rooms[i].width // 2
        start_y = rooms[i].y + rooms[i].height // 2
        end_x = rooms[i + 1].x + rooms[i + 1].width // 2
        end_y = rooms[i + 1].y + rooms[i + 1].height // 2

        current_x, current_y = start_x, start_y

        while current_x != end_x:
            Level.fields[current_y][current_x].symbol = "."
            Level.fields[current_y][current_x].wallPtr = False

            if current_x < end_x:
                current_x += 1
            else:
                current_x -= 1

        while current_y != end_y:
            Level.fields[current_y][current_x].symbol = "."
            Level.fields[current_y][current_x].wallPtr = False

            if current_y < end_y:
                current_y += 1
            else:
                current_y -= 1
