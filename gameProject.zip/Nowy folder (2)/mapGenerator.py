import random
from content import Level


class Room:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def intersects(self, Level, new_room):
        return (0 < new_room.x < Level.width - 1 and 0 < new_room.y < Level.height - 1
                and not Level.isWall(new_room.x - 1, new_room.y - 1) and not Level.isWall(new_room.height + 1,
                                                                                          new_room.width + 1))

    def get_center(self):
        center_x = self.x + self.width // 2
        center_y = self.y + self.height // 2
        return center_x, center_y

    def get_random_corner(self):
        random_number = random.randint(0, 3)
        if random_number == 0:
            return self.x+1, self.y+1
        elif random_number == 1:
            return self.x+self.width-1, self.y+1
        elif random_number == 2:
            return self.x+1, self.y+self.height-1
        elif random_number == 3:
            return self.x+self.width-1, self.y+self.height-1

def generateUniqueCoordinates(Level, num_coordinates):
    unique_coordinates = set()

    while len(unique_coordinates) < num_coordinates:
        x = random.randint(1, Level.width - 2)
        y = random.randint(1, Level.height - 2)

        # Sprawdź, czy koordynaty są unikalne
        if (x, y) not in unique_coordinates:
            unique_coordinates.add((x, y))

    return list(unique_coordinates)

def create_test_rooms(Level):
    rooms = []
    room_width = 6
    room_height = 6
    x = Level.width // 2 - 4
    y = Level.height // 2 - 4
    x2 = Level.width // 2 - 3
    y2 = Level.height // 2 - 3
    x3 = Level.width // 2 - 3
    y3 = Level.height // 2 - 3
    x4 = Level.width // 2 - 3
    y4 = Level.height // 2 - 3
    x5 = Level.width // 2 - 3
    y5 = Level.height // 2 - 3
    new_room = Room(x, y, room_width+2, room_height+2)
    rooms.append(new_room)
    for i in range(y, y + room_height+2):
        for j in range(x, x + room_width+2):
            Level.fields[i][j].symbol = "  "
            Level.fields[i][j].wallPtr = False

    x2 += room_width + 1
    y2 += 2
    new_room2 = Room(x2, y2, room_width, room_height-4)
    rooms.append(new_room2)
    for i in range(y2, y2 + room_height-4):
        for j in range(x2, x2 + room_width):
            Level.fields[i][j].symbol = " "
            Level.fields[i][j].wallPtr = False

    x3 -= room_width + 1
    y3 += 2
    new_room3 = Room(x3, y3, room_width, room_height-4)
    rooms.append(new_room3)
    for i in range(y3, y3 + room_height - 4):
        for j in range(x3, x3 + room_width):
            Level.fields[i][j].symbol = " "
            Level.fields[i][j].wallPtr = False

    x4 += 1
    y4 -= room_height-2
    new_room4 = Room(x4, y4, room_width-2, room_height-3)
    rooms.append(new_room4)
    for i in range(y4, y4 + room_height - 3):
        for j in range(x4, x4 + room_width - 2):
            Level.fields[i][j].symbol = " "
            Level.fields[i][j].wallPtr = False

    x5 += 1
    y5 += room_height + 1
    new_room5 = Room(x5, y5, room_width-2, room_height-3)
    rooms.append(new_room5)
    for i in range(y5, y5 + room_height-3):
        for j in range(x5, x5 + room_width-2):
            Level.fields[i][j].symbol = " "
            Level.fields[i][j].wallPtr = False

    return rooms

def create_rooms(Level, num_rooms, min_size, max_size):
    rooms = []
    while len(rooms) < num_rooms:
        room_width = random.randint(min_size, max_size)
        room_height = random.randint(min_size, max_size)

        x = random.randint(1, Level.width - room_width - 1)
        y = random.randint(1, Level.height - room_height - 1)
        if (Level.fields[y][x].wallPtr is True and
                Level.fields[y ][x + room_width].wallPtr is True and
                Level.fields[y + room_height][x].wallPtr is True and
                Level.fields[y + room_height][x + room_width].wallPtr is True):
            new_room = Room(x, y, room_width, room_height)
            rooms.append(new_room)
            for i in range(y, y + room_height):
                for j in range(x, x + room_width):
                    Level.fields[i][j].symbol = " "
                    Level.fields[i][j].wallPtr = False
    return rooms


def connect_rooms(Level, rooms):
    for i in range(len(rooms) - 1):
        start_x = rooms[i].x + rooms[i].width // 2
        start_y = rooms[i].y + rooms[i].height // 2
        end_x = rooms[i + 1].x + rooms[i + 1].width // 2
        end_y = rooms[i + 1].y + rooms[i + 1].height // 2

        current_x, current_y = start_x, start_y

        while current_x != end_x:
            Level.fields[current_y][current_x].symbol = " "
            Level.fields[current_y][current_x].wallPtr = False

            if current_x < end_x:
                current_x += 1
            else:
                current_x -= 1

        while current_y != end_y:
            Level.fields[current_y][current_x].symbol = " "
            Level.fields[current_y][current_x].wallPtr = False

            if current_y < end_y:
                current_y += 1
            else:
                current_y -= 1
