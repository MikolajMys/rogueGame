import random
from content import ElementOfGame
from hero import Hero

class Prop(ElementOfGame):
    def __init__(self, name, symbol, description, damage, range):
        super().__init__(name, symbol, description)
        self.damage = damage
        self.range = range

    def spawnItem(self, Level, x, y):
        if not Level.fields[y][x].actorPtr or not Level.fields[y][x].creaturePtr or not Level.isWall(x, y):
            # print("Item spawned")
            Level.info += " " + str(self.name) + " spawned,"
            Level.fields[y][x].itemPtr = self
            Level._saveToFile(f"{self.name} spawned at ({x}, {y})")
        else:
            Level.info = "Can't spawn item, field is occupied"

    def removeItem(self, Level, x, y):
        if Level.fields[y][x].itemPtr:
            # print("Item removed")
            Level.info += " " + str(self.name) + " removed,"
            Level.fields[y][x].itemPtr = None
            Level._removeFromFile(f"Item spawned at ({x}, {y})")
        else:
            Level.info = "No Item found on this field"

    def useItem(self, Hero, Level, rooms):
        if self.name == "Mysterious potion":
            size = len(rooms)
            Hero.x, Hero.y = rooms[random.randint(0, size - 1)].get_center()
            Level.info += " " + str(Hero.name) + " used " + str(self.name) + ","
            Hero.equipment.remove(self)
        if self.name == "Health potion":
            Hero.health = 50
            Level.info += " " + str(Hero.name) + " used " + str(self.name) + ","
            Hero.equipment.remove(self)
        if self.name == "Dagger":
            Hero.damage += self.damage
            Hero.range += self.range
            Level.info += " " + str(Hero.name) + " used " + str(self.name) + ","
            Hero.equipment.remove(self)
        if self.name == "Sword":
            Hero.damage += self.damage
            Hero.range += self.range
            Level.info += " " + str(Hero.name) + " used " + str(self.name) + ","
            Hero.equipment.remove(self)