# start_screen.py

import curses

def start_screen(stdscr):
    curses.curs_set(0)
    stdscr.clear()
    stdscr.addstr(9, 10, " / \\=========================/ \\", curses.A_BOLD)
    stdscr.addstr(10, 10, "| | |                       | | |", curses.A_BOLD)
    stdscr.addstr(11, 10, " \\ /  Welcome to Your Game!  \\ /", curses.A_BOLD)
    stdscr.addstr(12, 10, " / \\  Press Enter to start   / \\", curses.A_BOLD)
    stdscr.addstr(13, 10, "| | |                       | | |", curses.A_BOLD)
    stdscr.addstr(14, 10, " \\ /=========================\\ /", curses.A_BOLD)
    stdscr.refresh()

    key = stdscr.getch()
    while key != 10:  # 10 to kod ASCII dla Enter
        key = stdscr.getch()

def end_screen(stdscr):
    curses.curs_set(0)
    stdscr.clear()
    stdscr.addstr(9, 10, " / \\=========================/ \\", curses.A_BOLD)
    stdscr.addstr(10, 10, "| | |                       | | |", curses.A_BOLD)
    stdscr.addstr(11, 10, " \\ /        GAME OVER!       \\ /", curses.A_BOLD)
    stdscr.addstr(12, 10, " / \\     'q' - to leave      / \\", curses.A_BOLD)
    stdscr.addstr(13, 10, "| | |                       | | |", curses.A_BOLD)
    stdscr.addstr(14, 10, " \\ /=========================\\ /", curses.A_BOLD)
    stdscr.refresh()

    key = stdscr.getch()
    while key != ord('q'):
        key = stdscr.getch()


if __name__ == "__main__":
    curses.wrapper(start_screen)
