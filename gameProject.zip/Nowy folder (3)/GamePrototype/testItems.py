# Odczytaj zawartość pliku items_locations.txt i wyświetl
with open("items_locations.txt", "r") as file:
    items_data = file.read()

print(items_data)
