from content import Level
from content import Hero
from content import Prop
from content import Creature

def main():
    width = 40
    height = 20

    level = Level(width, height)
    level.generate()

    hero = Hero("Player", "@", "Main character", width // 2, height // 2, 50)
    sword = Prop("Sword", "!", "Melee weapon")
    rat = Creature("Rat", "S", "First enemy", 3)
    goblin = Creature("Player", "G", "Small enemy", 10)
    skeleton = Creature("Skeleton", "I", "Medium enemy", 15)
    zombie =  Creature("Zombie", "Z", "Hard medium enemy", 20)
    ogr = Creature("Ogr", "X", "Big enemy", 30)
    level.spawnHero(hero)
    level.spawnCreature(rat, 2 , 15)
    level.spawnCreature(goblin, 15, 2)
    level.spawnCreature(skeleton, 30, 10)
    level.spawnCreature(zombie, 20, 5)
    level.spawnCreature(ogr, 25, 12)
    level.spawnItem(sword, 10, 10)
    level.draw()
    level.showReport()
    #level.removeHero(20, 10)
    #level.removeItem(10, 10)
    #level.draw()
    #level.showReport()
if __name__ == "__main__":
    main()
